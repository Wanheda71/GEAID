<?php
    // Connexion à la base de données
    require '../php/database.php';
    global $db;
    session_start();
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="../css/styles.css" />
        <title>GEAID71</title>
    </head>
    <body>
        <div class="wrapper">
            <div class="logo-container">
            <a href="../php/accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
            </div>
        </div>
        
        <div class="container admin" align="center">
            <div class="row">
                <h1><strong>Liste des utilisateurs </strong><a href="utilisateurs/insert.php" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-plus"></span> Ajouter</a></h1>
            </div>
            <!-- Tableau affichant tous les utilisateurs -->
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>Role</th>
                        <th>Supérieur</th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Mail</th>
                        <th>Tel</th>
                        <th>Adresse</th>
                        <th>CP</th>
                        <th>Ville</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $statement = $db->query('SELECT * FROM utilisateur U INNER JOIN role R ON U.NumRole = R.NumRole ORDER BY R.NumRole'); //Sélectionne tous les utilisateurs de manière croissante en fonction du NumRole
                        while($utilisateur = $statement->fetch()) 
                        {
                            echo '<tr>';
                            echo '<td>'. $utilisateur['LibRole'] . '</td>';
                            echo '<td>'. $utilisateur['Superieur'] . '</td>';
                            echo '<td>'. $utilisateur['Nom'] . '</td>';
                            echo '<td>'. $utilisateur['Prenom'] . '</td>';
                            echo '<td>'. $utilisateur['Mail'] . '</td>';
                            echo '<td>'. $utilisateur['Tel'] . '</td>';
                            echo '<td>'. $utilisateur['Adresse'] . '</td>';
                            echo '<td>'. $utilisateur['CP'] . '</td>';
                            echo '<td>'. $utilisateur['Ville'] . '</td>';
                            echo '<td width=300>';
                            if($utilisateur['NumRole'] != 3 && $utilisateur['Superieur'] == NULL)
                            {
                                echo '<a class="btn btn-warning" style="margin-bottom:4px;" href="utilisateurs/assign.php?id='.$utilisateur['IdUti'].'"><span class="glyphicon glyphicon-ok"></span> Assigner un supérieur</a><br>';
                                echo ' ';
                            }
                            echo '<a class="btn btn-primary" href="utilisateurs/update.php?id='.$utilisateur['IdUti'].'"><span class="glyphicon glyphicon-pencil"></span> Modifier</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="utilisateurs/delete.php?id='.$utilisateur['IdUti'].'"><span class="glyphicon glyphicon-remove"></span> Supprimer</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    ?>
                </tbody>
            </table>
            <br>
            <br>
            <div class="row">
                <h1><strong>Planning </strong><a href="planning/insert.php" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-plus"></span> Ajouter</a></h1>
            </div>
            <!-- Tableau affichant tous les planning -->
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>Nom Prénom</th>
                        <th>Date</th>
                        <th>Plage1</th>
                        <th>Plage2</th>
                        <th>Plage3</th>
                        <th>Statut</th>
                        <th>Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $statement = $db->query('SELECT Nom,Prenom,Date,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,Statut,Total,IdPlanning FROM planning P INNER JOIN utilisateur U ON P.IdUti = U.IdUti ORDER BY Date'); //Sélectionne tous les planning de manière croissante en fonction de la date
                        while($planning = $statement->fetch()) 
                        {
                            echo '<tr>';
                            echo '<td>'. $planning['Nom'] . " " . $planning['Prenom'] .'</td>';
                            echo '<td>'. $planning['Date'] . '</td>';
                            if($planning['DebutPlage1'] != NULL && $planning['FinPlage1'] != NULL)
                            {
                                echo '<td>'. $planning['DebutPlage1'] . " à " . $planning['FinPlage1'] .'</td>';
                            }
                            else
                            {
                                echo '<td>'. $planning['DebutPlage1'] . " " . $planning['FinPlage1'] .'</td>';
                            }
                            if($planning['DebutPlage2'] != NULL && $planning['FinPlage2'] != NULL)
                            {
                                echo '<td>'. $planning['DebutPlage2'] . " à " . $planning['FinPlage2'] .'</td>';
                            }
                            else
                            {
                                echo '<td>'. $planning['DebutPlage2'] . " " . $planning['FinPlage2'] .'</td>';
                            }
                            if($planning['DebutPlage3'] != NULL && $planning['FinPlage3'] != NULL)
                            {
                                echo '<td>'. $planning['DebutPlage3'] . " à " . $planning['FinPlage3'] .'</td>';
                            }
                            else
                            {
                                echo '<td>'. $planning['DebutPlage3'] . " " . $planning['FinPlage3'] .'</td>';
                            }
                            echo '<td>'. $planning['Statut'] . '</td>';
                            echo '<td>'. $planning['Total'] . '</td>';
                            echo '<td width=300>';
                            echo '<a class="btn btn-primary" href="planning/update.php?id='.$planning['IdPlanning'].'"><span class="glyphicon glyphicon-pencil"></span> Modifier</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="planning/delete.php?id='.$planning['IdPlanning'].'"><span class="glyphicon glyphicon-remove"></span> Supprimer</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    ?>
                </tbody>
            </table>
            <br>
            <br>
            <div class="row">
                <h1><strong>Liste des plages non pointées</strong></h1>
            </div>
            <!-- Tableau affichant tous les oublis -->
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>Nom Prénom</th>
                        <th>Date</th>
                        <th>Plage1</th>
                        <th>Plage2</th>
                        <th>Plage3</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        date_default_timezone_set('Europe/Paris');
                        $date = date('Y-m-d');
                        $iduti = $_SESSION['IdUti'];

                        $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne tous les éléments de la table oubli les alignants de manière croissante par la date
                        $sup = $statement->fetch();

                        $Nom = $sup['Nom'];
                        $Prenom = $sup['Prenom'];

                        $statement = $db->query("SELECT Nom,Prenom,Date,Pointage1,Pointage2,Pointage3,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,IdPlanning,StatutAbs FROM utilisateur u INNER JOIN planning p ON u.IdUti = p.IdUti WHERE Statut = 'Travail' AND Date <= '$date' AND StatutAbs = 'En cours' AND Superieur = '$Nom $Prenom'"); //Sélectionne tous les éléments de la table utilisateur et planning permettant de montrer l'absence de pointage
                        while($absence = $statement->fetch()) 
                        {
                            echo '<tr>';
                            if($absence['Pointage1'] == NULL && $absence['DebutPlage1'] != NULL && $absence['FinPlage1'] != NULL || $absence['Pointage2'] == NULL && $absence['DebutPlage2'] != NULL && $absence['FinPlage2'] != NULL || $absence['Pointage3'] == NULL && $absence['DebutPlage3'] != NULL && $absence['FinPlage3'] != NULL)
                            {
                                echo '<td>'. $absence['Nom'] . " " . $absence['Prenom'] .'</td>';
                                echo '<td>'. $absence['Date'] . '</td>';
                                if($absence['DebutPlage1'] != NULL && $absence['FinPlage1'] != NULL && $absence['Pointage1'] == NULL && $absence['DebutPlage1'] != NULL && $absence['FinPlage1'] != NULL)
                                {
                                    echo '<td>'. $absence['DebutPlage1'] . " à " . $absence['FinPlage1'] .'</td>';
                                }
                                else
                                {
                                    echo '<td> </td>';
                                }
                                if($absence['DebutPlage2'] != NULL && $absence['FinPlage2'] != NULL && $absence['Pointage2'] == NULL && $absence['DebutPlage2'] != NULL && $absence['FinPlage2'] != NULL)
                                {
                                    echo '<td>'. $absence['DebutPlage2'] . " à " . $absence['FinPlage2'] .'</td>';
                                }
                                else
                                {
                                    echo '<td> </td>';
                                }
                                if($absence['DebutPlage3'] != NULL && $absence['FinPlage3'] != NULL && $absence['Pointage3'] == NULL && $absence['DebutPlage3'] != NULL && $absence['FinPlage3'] != NULL)
                                {
                                    echo '<td>'. $absence['DebutPlage3'] . " à " . $absence['FinPlage3'] .'</td>';
                                }
                                else
                                {
                                    echo '<td> </td>';
                                }
                                echo '<td>'. $absence['StatutAbs'] . '</td>';
                                echo '<td width=300>';
                                echo '<a class="btn btn-success" href="absence/accepterabsence.php?id='.$absence['IdPlanning'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                                echo ' ';
                                echo '<a class="btn btn-danger" href="absence/refuserabsence.php?id='.$absence['IdPlanning'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                                echo '</td>';
                            }
                            echo '</tr>';
                        }
                    ?>
                </tbody>
            </table>
            <br>
            <br>
            <div class="row">
                <h1><strong>Liste des oublis</strong></h1>
            </div>
            <!-- Tableau affichant tous les oublis -->
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>Nom Prénom</th>
                        <th>Commentaire</th>
                        <th>Date</th>
                        <th>Heure d'arrivée</th>
                        <th>Heure de départ</th>
                        <th>Durée</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $iduti = $_SESSION['IdUti'];

                        $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne le nom et prénom de l'utilisateur correspondant à l'id
                        $sup = $statement->fetch();

                        $Nom = $sup['Nom'];
                        $Prenom = $sup['Prenom'];

                        $statement = $db->query("SELECT Nom,Prenom,Commentaire,Date,HeureArrivee,HeureDepart,Duree,LibStatut,IdOubli FROM oubli O INNER JOIN utilisateur U ON O.IdUti = U.IdUti WHERE LibStatut = 'En cours' AND Superieur = '$Nom $Prenom' ORDER BY Date"); //Sélectionne tous les éléments de la table oubli les alignants de manière croissante par la date
                        while($oubli = $statement->fetch()) 
                        {
                            echo '<tr>';
                            echo '<td>'. $oubli['Nom'] . " " . $oubli['Prenom'] .'</td>';
                            echo '<td>'. $oubli['Commentaire'] . '</td>';
                            echo '<td>'. $oubli['Date'] . '</td>';
                            echo '<td>'. $oubli['HeureArrivee'] . '</td>';
                            echo '<td>'. $oubli['HeureDepart'] . '</td>';
                            echo '<td>'. $oubli['Duree'] . '</td>';
                            echo '<td>'. $oubli['LibStatut'] . '</td>';
                            echo '<td width=300>';
                            echo '<a class="btn btn-success" href="oubli/accepteroubliadmin.php?id='.$oubli['IdOubli'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="oubli/refuseroubliadmin.php?id='.$oubli['IdOubli'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    ?>
                </tbody>
            </table>
            <br>
            <br>
            <div class="row">
                <h1><strong>Liste des congés demandés</strong></h1>
            </div>
            <!-- Tableau affichant tous les congés demandés des supérieurs -->
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>Nom Prénom</th>
                        <th>Date de début</th>
                        <th>Date de fin</th>
                        <th>Période</th>
                        <th>Motif</th>
                        <th>Statut</th> 
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $iduti = $_SESSION['IdUti'];

                        $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne le nom et prenom de l'utilisateur actuel
                        $sup = $statement->fetch();

                        $Nom = $sup['Nom'];
                        $Prenom = $sup['Prenom'];
                    
                        $statement = $db->query("SELECT Nom,Prenom,DateDeb,DateFin,C.IdPeriode,Motif,LibStatut,IdConges,P.LibPeriode FROM conges C INNER JOIN utilisateur U ON C.IdUti = U.IdUti INNER JOIN periode P ON P.IdPeriode = C.IdPeriode WHERE Superieur = '$Nom $Prenom' AND C.LibStatut = 'En cours' ORDER BY DateDeb"); //Sélectionne tous congés demandés du N-1
                        while($conges = $statement->fetch()) 
                        {
                            echo '<tr>';
                            echo '<td>'. $conges['Nom'] . " " . $conges['Prenom'] .'</td>';
                            echo '<td>'. $conges['DateDeb'] . '</td>';
                            echo '<td>'. $conges['DateFin'] . '</td>';
                            echo '<td>'. $conges['LibPeriode'] . '</td>';
                            echo '<td>'. $conges['Motif'] . '</td>';
                            echo '<td>'. $conges['LibStatut'] . '</td>';
                            echo '<td width=300>';
                            echo '<a class="btn btn-success" href="conges/accepteradmin.php?id='.$conges['IdConges'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="conges/refuseradmin.php?id='.$conges['IdConges'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    ?>
                </tbody>
            </table>
            <br>
            <br>
            <div class="row">
                <h1><strong>Liste des alertes</strong></h1>
            </div>
            <!-- Tableau affichant toutes les alertes -->
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>Nom Prénom</th>
                        <th>Début requis</th>
                        <th>Fin requise</th>
                        <th>Heure de pointage</th>
                        <th>Message</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $statement = $db->query('SELECT Nom,Prenom,DebutPlage,FinPlage,HeurePointage,Message,IdAlerte,LibStatut FROM alerte A INNER JOIN utilisateur U ON A.IdUti = U.IdUti WHERE LibStatut = "En cours" ORDER BY Date'); //Sélectionne toutes les alertes
                        while($alerte = $statement->fetch()) 
                        {
                            echo '<tr>';
                            echo '<td>'. $alerte['Nom'] . " " . $alerte['Prenom'] .'</td>';
                            echo '<td>'. $alerte['DebutPlage'] . '</td>';
                            echo '<td>'. $alerte['FinPlage'] . '</td>';
                            echo '<td>'. $alerte['HeurePointage'] . '</td>';
                            echo '<td>'. $alerte['Message'] . '</td>';
                            echo '<td>'. $alerte['LibStatut'] . '</td>';
                            echo '<td width=300>';
                            echo '<a class="btn btn-success" href="alerte/accepteralerte.php?id='.$alerte['IdAlerte'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="alerte/refuseralerte.php?id='.$alerte['IdAlerte'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </body>
</html>