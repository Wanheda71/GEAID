<?php

    require '../../php/database.php'; //Récupère la base de données
    global $db;

    if(!empty($_GET['id'])) //Récupère l'id par l'url
    {
        $id = checkInput($_GET['id']);
    }

   $superieurError = $superieur = "";

    if(!empty($_POST)) 
    {
        //Création des variables
        $superieur    = checkInput($_POST['superieur']);
        $isSuccess    = true;
       
         if(empty($superieur)) //Si la variable superieur est vide alors:
        {
            $superieurError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
         
        if (($isSuccess) || ($isSuccess)) 
        { 
            if($isSuccess)
            {
                $statement = $db->prepare("UPDATE utilisateur set Superieur = ? WHERE IdUti = ?");//Modifie le superieur
                $statement->execute(array($superieur,$id));
            }
            header("Location: ../index.php");
        }
           
    }
    else 
    {
        $statement = $db->prepare("SELECT Superieur FROM utilisateur where IdUti = ?"); //Prépare la requete qui selectionne le superieur d'un utilisateur dont l'IdUti correspond à l'id
        $statement->execute(array($id));//Exécution de la requête
        $item = $statement->fetch();
        $superieur  = $item['Superieur'];
    }

    function checkInput($data) 
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../../css/styles.css" />
        <link rel="shortcut icon" href="../../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <title>GEAID71 - Page d'assignation</title>
    </head>
    
    <body>
        <header> 
            <!-- Logo -->
            <div class="wrapper">
                <div class="logo-container">
                    <a href="../../php/accueil.php"><img src="../../images/aide5.png" alt="logo"/></a>
                </div>
            </div>
        </header>

         <div class="container admin">
            <div class="row">
                <h1><strong>Assigner un supérieur</strong></h1>
                <br>
                <form class="form" action="<?php echo 'assign.php?id='.$id;?>" role="form" method="post" enctype="multipart/form-data"> <!-- Création d'un formulaire faisant appel à la page assign.php?id -->
                    <div class="form-group">
                        <label for="superieur">Supérieur:</label>
                        <select class="form-control" id="superieur" name="superieur">
                        <?php
                            $statement = $db->query("SELECT NumRole FROM utilisateur WHERE IdUti = '$id'"); //Sélectionne le role de l'utilisateur
                            $NumRole = $statement->fetch();
                            if($NumRole['NumRole'] == 1)
                            {
                                $statement = $db->query('SELECT Nom,Prenom FROM utilisateur WHERE NumRole = 2'); //Sélectionne le role superieur
                                while($Select2 = $statement->fetch()) 
                                {
                                    echo '<option value="'.$Select2['Nom'].' '.$Select2['Prenom'].' ">'.$Select2['Nom'].' '.$Select2['Prenom'].'</option>';//Création d'un combobox qui récupère le Nom et Prenom et affichant le Nom et Prenom
                                }
                            }
                            else
                            {
                                if($NumRole['NumRole'] == 2)
                                {
                                    $statement = $db->query('SELECT Nom,Prenom FROM utilisateur WHERE NumRole = 3'); //Sélectionne le role superieur
                                    while($Select3 = $statement->fetch()) 
                                    {
                                        echo '<option value="'.$Select3['Nom'].' '.$Select3['Prenom'].' ">'.$Select3['Nom'].' '.$Select3['Prenom'].'</option>';//Création d'un combobox qui récupère le Nom et Prenom et affichant le Nom et Prenom
                                    }
                                }
                            }
                        ?>
                        </select>
                        <span class="help-inline"><?php echo $superieurError;?></span>
                    </div>
                    <br>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-ok"></span> Assigner</button>
                        <a class="btn btn-primary" href="../index.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                    </div>
                </form>
            </div>
        </div>   
    </body>
</html>
