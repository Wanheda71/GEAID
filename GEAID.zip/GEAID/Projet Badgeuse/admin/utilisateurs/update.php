<?php
    require '../../php/database.php'; //Récupère la base de données
    global $db;

    if(!empty($_GET['id'])) //Récupère l'id par l'url
    {
        $id = checkInput($_GET['id']);
    }

   $roleError = $superieurError = $nameError = $prenomError = $mailError = $telError = $adresseError = $cpError = $villeError = $role = $superieur = $name = $prenom = $mail = $tel = $adresse = $cp = $ville = "";

    if(!empty($_POST)) 
    {
        //Création des variables
        $role               = checkInput($_POST['role']);
        $superieur          = checkInput($_POST['superieur']);
        $name               = checkInput($_POST['name']);
        $prenom             = checkInput($_POST['prenom']);
        $mail               = checkInput($_POST['mail']);
        $tel                = checkInput($_POST['tel']);
        $adresse            = checkInput($_POST['adresse']);
        $cp                 = checkInput($_POST['cp']);
        $ville              = checkInput($_POST['ville']);
        $isSuccess          = true;
       
        if(empty($role)) //Si la variable role est vide alors:
        {
            $roleError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($name)) //Si la variable name est vide alors:
        {
            $nameError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        } 
        if(empty($prenom)) //Si la variable prenom est vide alors:
        {
            $prenomError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        } 
        if(empty($mail)) //Si la variable mail est vide alors:
        {
            $mailError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($tel)) //Si la variable tel est vide alors:
        {
            $telError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($adresse)) //Si la variable adresse est vide alors:
        {
            $adresseError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($cp)) //Si la variable cp est vide alors:
        {
            $cpError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($ville)) //Si la variable ville est vide alors:
        {
            $villeError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
       
         
        if (($isSuccess) || ($isSuccess)) 
        { 
            if($isSuccess)
            {
                $statement = $db->prepare("UPDATE utilisateur set NumRole = ?, Superieur = ?, Nom = ?, Prenom = ?, Mail = ?, Tel = ?, Adresse = ?, CP = ?, Ville = ? WHERE IdUti = ?");//Modifie les valeurs d'un utilisateur
                $statement->execute(array($role,$superieur,$name,$prenom,$mail,$tel,$adresse,$cp,$ville,$id));
            }
            header("Location: ../index.php");
        }
           
    }
    else 
    {
        $statement = $db->prepare("SELECT * FROM utilisateur where IdUti = ?"); //Prépare la requete qui selectionne toutes les données d'un utilisateur dont l'IdUti correspond à l'id
        $statement->execute(array($id));//Exécution de la requête
        $item = $statement->fetch();
        $role      = $item['NumRole'];
        $superieur = $item['Superieur'];
        $name      = $item['Nom'];
        $prenom    = $item['Prenom'];
        $mail      = $item['Mail'];
        $tel       = $item['Tel'];
        $adresse   = $item['Adresse'];
        $cp        = $item['CP'];
        $ville     = $item['Ville'];
    }

    function checkInput($data) 
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../../css/styles.css" />
        <link rel="shortcut icon" href="../../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <title>GEAID71 - Page de modification</title>
    </head>
    
    <body>
        <header> 
            <!-- Logo -->
            <div class="wrapper">
                <div class="logo-container">
                    <a href="../../php/accueil.php"><img src="../../images/aide5.png" alt="logo"/></a>
                </div>
            </div>
        </header>

         <div class="container admin">
            <div class="row">
                <h1><strong>Modifier un utilisateur</strong></h1>
                <br>
                <form class="form" action="<?php echo 'update.php?id='.$id;?>" role="form" method="post" enctype="multipart/form-data"> <!-- Création d'un formulaire faisant appel à la page update.php?id -->
                    <div class="form-group">
                        <label for="role">Role:</label>
                        <select class="form-control" id="role" name="role">
                        <?php
                            foreach ($db->query('SELECT * FROM role') as $row) //Sélectionne tous les roles
                            {
                                if($row['NumRole'] == $role)
                                    echo '<option selected="selected" value="'.$row['NumRole'].'">'.$row['LibRole'].'</option>';
                                else
                                    echo '<option value="'. $row['NumRole'] .'">'.$row['LibRole'].'</option>';;
                            }
                        ?>
                        </select>
                        <span class="help-inline"><?php echo $roleError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="superieur">Supérieur:</label>
                        <select class="form-control" id="superieur" name="superieur">
                        <?php
                            $statement = $db->query("SELECT NumRole FROM utilisateur WHERE IdUti = '$id'"); //Sélectionne le role de l'utilisateur
                            $NumRole = $statement->fetch();
                            if($NumRole['NumRole'] == 1)
                            {
                                foreach ($db->query('SELECT Nom,Prenom,Superieur FROM utilisateur WHERE NumRole = 2') as $row) //Sélectionne tous les supérieurs
                                {
                                    if($row['Superieur'] != NULL)
                                        echo '<option selected="selected" value="'.$row['Nom'].' '.$row['Prenom'].' ">'.$row['Nom'].' '.$row['Prenom'].'</option>';
                                    else
                                        echo '<option value="'.$row['Nom'].' '.$row['Prenom'].' ">'.$row['Nom'].' '.$row['Prenom'].'</option>';
                                }
                            }
                            else
                            {
                                if($NumRole['NumRole'] == 2)
                                {
                                    foreach ($db->query('SELECT Nom,Prenom,Superieur FROM utilisateur WHERE NumRole = 3') as $row) //Sélectionne tous les administrateurs
                                    {
                                        if($row['Superieur'] != NULL)
                                            echo '<option selected="selected" value="'.$row['Nom'].' '.$row['Prenom'].' ">'.$row['Nom'].' '.$row['Prenom'].'</option>';
                                        else
                                            echo '<option value="'.$row['Nom'].' '.$row['Prenom'].' ">'.$row['Nom'].' '.$row['Prenom'].'</option>';
                                    }
                                }
                                else
                                {
                                    echo 'Vous ne pouvez pas attribuer de supérieur.';
                                }
                            }
                        ?>
                        </select>
                        <span class="help-inline"><?php echo $superieurError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="name">Nom :</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Nom" value="<?php echo $name;?>">
                        <span class="help-inline"><?php echo $nameError;?></span>
                    </div>

                    <div class="form-group">
                        <label for="prenom">Prénom :</label>
                        <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prénom" value="<?php echo $prenom;?>">
                        <span class="help-inline"><?php echo $prenomError;?></span>
                    </div>

                    <div class="form-group">
                    <label for="mail">Mail :</label>
                        <input type="email" class="form-control" id="mail" name="mail" placeholder="mail" value="<?php echo $mail;?>">
                        <span class="help-inline"><?php echo $mailError;?></span>
                    </div>

                    <div class="form-group">
                    <label for="tel">Téléphone :</label>
                        <input type="tel" class="form-control" id="tel" name="tel" placeholder="Téléphone" value="<?php echo $tel;?>">
                        <span class="help-inline"><?php echo $telError;?></span>
                    </div>

                    <div class="form-group">
                    <label for="adresse">Adresse :</label>
                        <input type="text" class="form-control" id="adresse" name="adresse" placeholder="Adresse" value="<?php echo $adresse;?>">
                        <span class="help-inline"><?php echo $adresseError;?></span>
                    </div>

                    <div class="form-group">
                    <label for="ville">Ville :</label>
                        <input type="text" class="form-control" id="ville" name="ville" placeholder="Ville" value="<?php echo $ville;?>">
                        <span class="help-inline"><?php echo $villeError;?></span>
                    </div>

                    <div class="form-group">
                    <label for="cp">CP :</label>
                        <input type="text" class="form-control" id="cp" name="cp" placeholder="cp" value="<?php echo $cp;?>">
                        <span class="help-inline"><?php echo $cpError;?></span>
                    </div>
                    <br>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Modifier</button>
                        <a class="btn btn-primary" href="../index.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                    </div>
                </form>
            </div>
        </div>   
    </body>
</html>