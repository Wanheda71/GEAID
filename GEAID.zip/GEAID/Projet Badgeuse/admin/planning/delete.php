<?php
    //Connexion à la BBD
    require '../../php/database.php';
    global $db;
 
    if(!empty($_GET['id'])) 
    {
        $id = checkInput($_GET['id']);
    }

    //Si le formulaire n'est pas vide alors:
    if(!empty($_POST)) {
        $errors = array();
        $id = checkInput($_POST['id']); //Récupère l'id
        $statement = $db->prepare("DELETE FROM planning WHERE IdPlanning = ?"); //Prepare la suppression du planning dont l'IdPlanning est l'id
        $statement->execute(array($id));//Execute la requete
        header("Location: ../index.php"); //Renvoie à la page index.php de l'admin
    }

    function checkInput($data) //Fonction permettant de sécuriser les données entrées dans le formulaire
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../../css/styles.css" />
        <link rel="shortcut icon" href="../../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <title>GEAID71 - Page de suppression</title>
    </head>
    
    <body>
        <header> 
            <!-- Logo -->
            <div class="wrapper">
                <div class="logo-container">
                    <a href="../../php/accueil.php"><img src="../../images/aide5.png" alt="logo"/></a>
                </div>
            </div>
        </header>

         <div class="container admin">
            <div class="row">
                <?php 
                    //Si nous pouvons récupérer l'id à partir de l'url alors:
                    if(!empty($_GET['id'])) 
                    {
                        $id = checkInput($_GET['id']); //Déclaration de la variable id
                    }
                    $reqU = $db->query("SELECT * FROM planning where IdPlanning = $id");//Selectionne le planning dont l'IdPlanning est égal à l'id
                    while($donnees = $reqU->fetch()){ //Tant qu'il reste des données à parcourir alors:
                        echo '<h1><strong>Supprimer le planning de l\'utilisateur '.$donnees['IdUti'].' pour le '.$donnees['Date'].' ?</strong></h1>';
                    }
                ?>
                <br>
                <form class="form" action="delete.php" role="form" method="post">
                    <input type="hidden" name="id" value="<?php echo $id;?>"/>
                    <p class="alert alert-warning">Êtes vous sûr de vouloir supprimer ce planning ?</p>
                    <div class="form-actions">
                      <button type="submit" class="btn btn-warning">Oui</button>
                      <a class="btn btn-default" href="../index.php">Non</a>
                    </div>
                </form>
            </div>
        </div>   
    </body>
</html>