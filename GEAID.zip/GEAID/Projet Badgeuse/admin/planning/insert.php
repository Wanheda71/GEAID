<?php
    //Connexion à la BBD
    require '../../php/database.php';
    global $db;
 
    $idutiError = $dateError = $iduti = $date = $debplage1 = $debplage2 = $debplage3 = $finplage1 = $finplage2 = $finplage3 = "";
    //Si le formulaire n'est pas vide alors:
    if(!empty($_POST)) 
    {
        //Création des variables
        $iduti              = checkInput($_POST['iduti']);
        $date               = checkInput($_POST['date']);
        $debplage1          = checkInput($_POST['debplage1']);
        $finplage1          = checkInput($_POST['finplage1']);
        $debplage2          = checkInput($_POST['debplage2']);
        $finplage2          = checkInput($_POST['finplage2']);
        $debplage3          = checkInput($_POST['debplage3']);
        $finplage3          = checkInput($_POST['finplage3']);
        $isSuccess          = true;
        $isUploadSuccess    = false;
        
        if(empty($iduti)) //Si la variable iduti est vide alors:
        {
            $idutiError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($date)) //Si la variable date est vide alors:
        {
            $dateError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        } 
        else //Sinon
        {
            $isUploadSuccess = true;
        }
        
        if($isSuccess && $isUploadSuccess) //Si $isSuccess && $isUploadSuccess sont true alors on insert les données dans la table planning 
        {
            if($debplage1 == NULL && $debplage2 == NULL && $debplage3 == NULL && $finplage1 == NULL && $finplage2 == NULL && $finplage3 == NULL)
            {
                $statement = $db->prepare("INSERT INTO planning(IdUti,Date,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,Statut,Total) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $statement->execute(array($iduti,$date,NULL,NULL,NULL,NULL,NULL,NULL,'Repos','00:00:00'));
                header("Location: ../index.php"); //Redirige vers la page index.php lorsque les données sont insérées
            }
            elseif($debplage1 != NULL && $debplage2 == NULL && $debplage3 == NULL && $finplage1 != NULL && $finplage2 == NULL && $finplage3 == NULL)
            {
                $statement = $db->prepare("INSERT INTO planning(IdUti,Date,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,Statut,Total) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $statement->execute(array($iduti,$date,$debplage1,NULL,NULL,$finplage1,NULL,NULL,'Travail','00:00:00'));

                $statement = $db->query("SELECT MAX(IdPlanning) AS MaxId FROM planning"); //Sélectionne le dernier planning effectué
                $MaxId = $statement->fetch();

                $max = $MaxId['MaxId'];

                $total = $db->query("SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(FinPlage1-DebutPlage1))) AS Total FROM planning WHERE IdPlanning = '$max'"); //Selectionne le temps de travail total du dernier planning en fonction des horaires
                $Total = $total->fetch();

                $tot = $Total['Total'];

                $statement = $db->prepare("UPDATE planning set Total = ? WHERE IdPlanning = ?"); //Modifie la valeur total du planning
                $statement->execute(array($tot,$max));

                header("Location: ../index.php"); //Redirige vers la page index.php lorsque les données sont insérées
            }
            elseif($debplage1 != NULL && $debplage2 != NULL && $debplage3 == NULL && $finplage1 != NULL && $finplage2 != NULL && $finplage3 == NULL)
            {
                $statement = $db->prepare("INSERT INTO planning(IdUti,Date,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,Statut,Total) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $statement->execute(array($iduti,$date,$debplage1,$debplage2,NULL,$finplage1,$finplage2,NULL,'Travail','00:00:00'));

                $statement = $db->query("SELECT MAX(IdPlanning) AS MaxId FROM planning"); //Sélectionne le dernier planning effectué
                $MaxId = $statement->fetch();

                $max = $MaxId['MaxId'];

                $total = $db->query("SELECT SEC_TO_TIME(SUM(TIME_TO_SEC((FinPlage1-DebutPlage1)+(FinPlage2-DebutPlage2)))) AS Total FROM planning WHERE IdPlanning = '$max'"); //Selectionne le temps de travail total du dernier planning en fonction des horaires
                $Total = $total->fetch();

                $tot = $Total['Total'];

                $statement = $db->prepare("UPDATE planning set Total = ? WHERE IdPlanning = ?"); //Modifie la valeur total du planning
                $statement->execute(array($tot,$max));

                header("Location: ../index.php"); //Redirige vers la page index.php lorsque les données sont insérées
            }
            elseif($debplage1 != NULL && $debplage2 != NULL && $debplage3 != NULL && $finplage1 != NULL && $finplage2 != NULL && $finplage3 != NULL)
            {
                $statement = $db->prepare("INSERT INTO planning(IdUti,Date,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,Statut,Total) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $statement->execute(array($iduti,$date,$debplage1,$debplage2,$debplage3,$finplage1,$finplage2,$finplage3,'Travail','00:00:00'));

                $statement = $db->query("SELECT MAX(IdPlanning) AS MaxId FROM planning"); //Sélectionne le dernier planning effectué
                $MaxId = $statement->fetch();

                $max = $MaxId['MaxId'];

                $total = $db->query("SELECT SEC_TO_TIME(SUM(TIME_TO_SEC((FinPlage1-DebutPlage1)+(FinPlage2-DebutPlage2)+(FinPlage3-DebutPlage3)))) AS Total FROM planning WHERE IdPlanning = '$max'"); //Selectionne le temps de travail total du dernier planning en fonction des horaires
                $Total = $total->fetch();

                $tot = $Total['Total'];

                $statement = $db->prepare("UPDATE planning set Total = ? WHERE IdPlanning = ?"); //Modifie la valeur total du planning
                $statement->execute(array($tot,$max));

                header("Location: ../index.php"); //Redirige vers la page index.php de l'admin lorsque les données sont insérées
            }
        }
    }

    function checkInput($data) //Fonction permettant de sécuriser les données entrées dans le formulaire
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../../css/styles.css" />
        <link rel="shortcut icon" href="../../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <title>GEAID71 - Page d'insertion</title>
    </head>
    
    <body>
        <header> 
            <!-- Logo -->
            <div class="wrapper">
                <div class="logo-container">
                    <a href="../../php/accueil.php"><img src="../../images/aide5.png" alt="logo"/></a>
                </div>
            </div>
            
        </header>
         <div class="container admin">
            <div class="row">
                <h1><strong>Ajouter un planning</strong></h1>
                <br>
                <!-- Formulaire pour insérer un planning -->
                <form class="form" action="insert.php" role="form" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="iduti">IdUti:</label>
                        <select class="form-control" id="iduti" name="iduti">
                        <?php
                           $statement = $db->query('SELECT IdUti, Nom, Prenom FROM utilisateur ORDER BY IdUti'); //Sélectionne tous les IdUti
                            while($Select = $statement->fetch()) 
                            {
                                echo '<option value="'.$Select['IdUti'].'">'.$Select['Nom'].' '.$Select['Prenom'].'</option>';//Création d'un combobox qui récupère l'IdUti et affichant le Nom et Prenom
                            }
                        ?>
                        </select>
                        <span class="help-inline"><?php echo $idutiError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" placeholder="Date" value="<?php echo $date;?>">
                        <span class="help-inline"><?php echo $dateError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="debplage1">Heure debut 1ere plage:</label>
                        <input type="time" class="form-control" id="debplage1" name="debplage1" value="<?php echo $debplage1;?>">
                    </div>
                    <div class="form-group">
                        <label for="finplage1">Heure fin 1ere plage:</label>
                        <input type="time" class="form-control" id="finplage1" name="finplage1" value="<?php echo $finplage1;?>">
                    </div>
                    <div class="form-group">
                        <label for="debplage2">Heure debut 2eme plage:</label>
                        <input type="time" class="form-control" id="debplage2" name="debplage2" value="<?php echo $debplage2;?>">
                    </div>
                    <div class="form-group">
                        <label for="finplage2">Heure fin 2eme plage:</label>
                        <input type="time" class="form-control" id="finplage2" name="finplage2" value="<?php echo $finplage2;?>">
                    </div>
                    <div class="form-group">
                        <label for="debplage3">Heure debut 3eme plage:</label>
                        <input type="time" class="form-control" id="debplage3" name="debplage3" value="<?php echo $debplage3;?>">
                    </div>
                    <div class="form-group">
                        <label for="finplage3">Heure fin 3eme plage:</label>
                        <input type="time" class="form-control" id="finplage3" name="finplage3" value="<?php echo $finplage3;?>">
                    </div>
                    <br>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Ajouter</button>
                        <a class="btn btn-primary" href="../index.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                    </div>
                </form>
            </div>
        </div>   
    </body>
</html>