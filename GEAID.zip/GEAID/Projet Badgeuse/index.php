<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <title>GEAID71</title>
</head>
<body class="index">
    <header>
        <div class="wrapper">
            <div class="logo-containeri">
                <img src="images/aide6.png" alt="logo"/>
            </div>
        </div>
    </header>

    <div class="header">
        <main>
            <br/>
            <section class="connect-container">
                <div class="connexion-login">
                    <h1>Bonjour, passez une bonne journée.</h1>
                    <h3>Veuillez vous connecter</h3>
                    <form method="POST">
                        <div class="formulaire-lemail">
                            <input type="email" name="lemail" autocomplete="off" required/>
                            <label for="lemail" class="label-name">
                                <span class="lemail-name">Email *</span>
                            </label>
                        </div>
                        <div class="formulaire-lpassword">
                            <input type="password" name="lpassword" autocomplete="off" required/>
                            <label for="lpassword" class="label-name">
                                <span class="lemail-name">Mot de Passe *</span>
                            </label>
                        </div>
                        <input class="btnco" type="submit" value="Connexion" name="formlogin" id="formlogin">
                    </form>

                    <?php
                        if(isset($_POST['formlogin'])) {
                            extract($_POST);

                            include 'php/database.php';
                            global $db;

                            if(!empty($lemail) && !empty($lpassword)) {
                                $q = $db->prepare("SELECT * FROM utilisateur WHERE Mail = '$lemail'"); //Sélectionne les données de l'utilisateur correspondant au mail entré
                                $q->execute(['Mail' => $lemail]);
                                $result = $q->fetch();

                                
                                if($result == true) {                                
                                    //Le compte existe bien 
                                    $hashpassword = $result['Mdp'];
                                
                                    if($lpassword == $hashpassword) {
                                        session_start();
                                        $_SESSION['Mail'] = $result['Mail'];
                                        $_SESSION['Mdp'] = $result['Mdp'];
                                        $_SESSION['IdUti'] = $result['IdUti'];
                                        $_SESSION['NumRole'] = $result['NumRole'];

                                        header('Location: php/accueil.php');
                                        exit();
                                    } else {
                                        echo '<h2>Mot de passe incorrect.</h2>';
                                    }
                                } else {
                                    echo '<h2>' .$lemail. ' n\'existe pas.</h2>';
                                }
                            } else {
                                echo '<h2>Champs incomplets</h2>';
                            }
                        }
                    ?>
                </div>
            </section>
        </main>
    </div>
</body>
</html>