<?php 
    session_start();
    include 'database.php';
    global $db;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../css/styles.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <title>GEAID71</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';
                            echo'<li><a class="link" href="sortie.php">Départ</a></li>';  
                            echo'<li><a class="link" href="conges.php">Congés</a></li>';  
                            echo'<li><a class="link" href="demandes.php">Mes Demandes</a></li>';
                            echo'<li><a class="link" href="pointages.php">Mes Pointages</a></li>';
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>';    
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 2) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 2 alors ajoute la partie Temps de travail dans la navbar
                            {  
                                echo'<li><a class="link" href="tpstravail.php">Employés</a></li>';
                            } 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            }
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="header">
        <main>
            <br/>
            <section class="connect-container">
                <div class="valide">
                    <h1>Votre arrivée à bien été enregistrée. <br><br><span style="color: red; font-size: 25px">N'oubliez pas de valider votre départ lorsque vous avez terminé.</span></h1>
                    <a href="accueil.php"><button class="btn-accueil">Retour à l'accueil</button></a>
                </div>
                <?php
                    date_default_timezone_set('Europe/Paris');
                    $heure = date('H:i:s');
                    $date = date('Y-m-d');
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT Statut, Total, Date, DebutPlage1, DebutPlage2, DebutPlage3, FinPlage1, FinPlage2, FinPlage3, SEC_TO_TIME(SUM(TIME_TO_SEC(DebutPlage1-TempsMarge))) AS MoinsDebPlan1, SEC_TO_TIME(SUM(TIME_TO_SEC(DebutPlage1+TempsMarge))) AS PlusDebPlan1, SEC_TO_TIME(SUM(TIME_TO_SEC(DebutPlage2-TempsMarge))) AS MoinsDebPlan2, SEC_TO_TIME(SUM(TIME_TO_SEC(DebutPlage2+TempsMarge))) AS PlusDebPlan2, SEC_TO_TIME(SUM(TIME_TO_SEC(DebutPlage3-TempsMarge))) AS MoinsDebPlan3, SEC_TO_TIME(SUM(TIME_TO_SEC(DebutPlage3+TempsMarge))) AS PlusDebPlan3 FROM planning WHERE IdUti = '$iduti' AND Date = '$date' GROUP BY Statut, Total, Date, DebutPlage1, DebutPlage2, DebutPlage3, FinPlage1, FinPlage2, FinPlage3"); //Sélectionne les données de la table planning ainsi que les plage horaires avec leur marge
                    $reqplanning = $statement->fetch();

                    $MoinsDebPlan1 = $reqplanning['MoinsDebPlan1'];
                    $PlusDebPlan1 = $reqplanning['PlusDebPlan1'];
                    $MoinsDebPlan2 = $reqplanning['MoinsDebPlan2'];
                    $PlusDebPlan2 = $reqplanning['PlusDebPlan2'];
                    $MoinsDebPlan3 = $reqplanning['MoinsDebPlan3'];
                    $PlusDebPlan3 = $reqplanning['PlusDebPlan3'];

                    $statement = $db->query("SELECT MAX(Id) AS ID FROM pointage WHERE IdUti = '$iduti'"); //Sélectionne la dernière ligne de la table pointage dont l'utilisateur correspond à l'id
                    $ID = $statement->fetch();

                    $statement = $db->query("SELECT NumPointage, date(DateDeb) as DateDeb FROM pointage WHERE Id = '".$ID['ID']."'"); //Sélectionne des données de la dernière ligne de la table pointage dont l'utilisateur correspond à l'id
                    $ID2 = $statement->fetch();

                    $statement = $db->query("SELECT MAX(Id) AS ID FROM pointage WHERE IdUti = '$iduti' AND date(DateDeb) = '$date' AND NumPointage = 1"); //Sélectionne la dernière ligne de la table pointage dont le NumPointage est égal à 1
                    $id1 = $statement->fetch();
                    $statement = $db->query("SELECT MAX(Id) AS ID FROM pointage WHERE IdUti = '$iduti' AND date(DateDeb) = '$date' AND NumPointage = 2"); //Sélectionne la dernière ligne de la table pointage dont le NumPointage est égal à 2
                    $id2 = $statement->fetch();
                    $statement = $db->query("SELECT MAX(Id) AS ID FROM pointage WHERE IdUti = '$iduti' AND date(DateDeb) = '$date' AND NumPointage = 3"); //Sélectionne la dernière ligne de la table pointage dont le NumPointage est égal à 3
                    $id3 = $statement->fetch();

                    $statement = $db->query("SELECT time(DateDeb) as Deb1 FROM pointage WHERE Id = '".$id1['ID']."'"); //Sélectionne des données de la dernière ligne de la table pointage dont le NumPointage est égal à 1
                    $deb1 = $statement->fetch();
                    $statement = $db->query("SELECT time(DateDeb) as Deb2 FROM pointage WHERE Id = '".$id2['ID']."'"); //Sélectionne des données de la dernière ligne de la table pointage dont le NumPointage est égal à 2
                    $deb2 = $statement->fetch();
                    $statement = $db->query("SELECT time(DateDeb) as Deb3 FROM pointage WHERE Id = '".$id3['ID']."'"); //Sélectionne des données de la dernière ligne de la table pointage dont le NumPointage est égal à 3
                    $deb3 = $statement->fetch();

                    if($ID2['NumPointage'] == 1 && $deb1['Deb1'] <= $MoinsDebPlan1 && $reqplanning['Date'] == $date && $reqplanning['Statut'] == 'Travail' || $ID2['NumPointage'] == 1 && $deb1['Deb1'] >= $PlusDebPlan1 && $reqplanning['Date'] == $date && $reqplanning['Statut'] == 'Travail')
                    {
                        $Date1 = $reqplanning['Date'];
                        $DebutPlage1 = $reqplanning['DebutPlage1'];
                        $FinPlage1 = $reqplanning['FinPlage1'];
                        $Message1 = 'Arrivée du premier pointage non valide.';

                        $alerte = $db->prepare("INSERT INTO alerte(IdUti, Date, DebutPlage, FinPlage, HeurePointage, Message) VALUES('$iduti', '$Date1', '$DebutPlage1', '$FinPlage1', '$heure', '$Message1')"); //Insert une nouvelle ligne dans la table alerte
                        $alerte->execute([
                        'IdUti' => $iduti,
                        'Date' => $Date1,
                        'DebutPlage' => $DebutPlage1,
                        'FinPlage' => $FinPlage1,
                        'HeurePointage' => $heure,
                        'Message' => $Message1
                        ]);
                    }
                    elseif($ID2['NumPointage'] == 2 && $deb2['Deb2'] <= $MoinsDebPlan2 && $reqplanning['Date'] == $date && $reqplanning['Statut'] == 'Travail' || $ID2['NumPointage'] == 2 && $deb2['Deb2'] >= $PlusDebPlan2 && $reqplanning['Date'] == $date && $reqplanning['Statut'] == 'Travail')
                    {
                        
                        $Date2 = $reqplanning['Date'];
                        $DebutPlage2 = $reqplanning['DebutPlage2'];
                        $FinPlage2 = $reqplanning['FinPlage2'];
                        $Message2 = "Arrivée du deuxième pointage non valide.";

                        $alerte = $db->prepare("INSERT INTO alerte(IdUti, Date, DebutPlage, FinPlage, HeurePointage, Message) VALUES('$iduti', '$Date2', '$DebutPlage2', '$FinPlage2', '$heure', '$Message2')"); //Insert une nouvelle ligne dans la table alerte
                        $alerte->execute([
                        'IdUti' => $iduti,
                        'Date' => $Date2,
                        'DebutPlage' => $DebutPlage2,
                        'FinPlage' => $FinPlage2,
                        'HeurePointage' => $heure,
                        'Message' => $Message2
                        ]);
                    }
                    elseif($ID2['NumPointage'] == 3 && $deb3['Deb3'] <= $MoinsDebPlan3 && $reqplanning['Date'] == $date && $reqplanning['Statut'] == 'Travail' || $ID2['NumPointage'] == 3 && $deb3['Deb3'] >= $PlusDebPlan3 && $reqplanning['Date'] == $date && $reqplanning['Statut'] == 'Travail')
                    {
                        $Date3 = $reqplanning['Date'];
                        $DebutPlage3 = $reqplanning['DebutPlage3'];
                        $FinPlage3 = $reqplanning['FinPlage3'];
                        $Message3 = 'Arrivée du troisième pointage non valide.';

                        $alerte = $db->prepare("INSERT INTO alerte(IdUti, Date, DebutPlage, FinPlage, HeurePointage, Message) VALUES('$iduti', '$Date3', '$DebutPlage3', '$FinPlage3', '$heure', '$Message3')"); //Insert une nouvelle ligne dans la table alerte
                        $alerte->execute([
                        'IdUti' => $iduti,
                        'Date' => $Date3,
                        'DebutPlage' => $DebutPlage3,
                        'FinPlage' => $FinPlage3,
                        'HeurePointage' => $heure,
                        'Message' => $Message3
                        ]);
                    }
                ?>
            </section>
        </main>
    </div>
</body>
</html>