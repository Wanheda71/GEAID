<?php
    // Connexion à la base de données
    session_start();
    require 'database.php';
    global $db;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/styles.css" />
    <title>GEAID71</title>
</head>
<body>
<header>
        <div class="wrapper">
            <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';
                            echo'<li><a class="link" href="sortie.php">Départ</a></li>';  
                            echo'<li><a class="link" href="conges.php">Congés</a></li>';  
                            echo'<li><a class="link" href="demandes.php">Mes Demandes</a></li>';  
                            echo'<li><a class="link" href="pointages.php">Mes Pointages</a></li>';
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>';
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            } 
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container admin" align="center">
        <div class="row">
            <h1><strong>Liste des temps de travail </strong><a href="travail/insert.php" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-plus"></span> Ajouter</a></h1>
        </div>
        <!-- Tableau affichant tous les temps de travail -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Nom Prénom</th>
                    <th>Date</th>
                    <th>Temps de travail</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne le nom et prenom de l'utilisateur actuel
                    $sup = $statement->fetch();

                    $Nom = $sup['Nom'];
                    $Prenom = $sup['Prenom'];
                
                    $statement = $db->query("SELECT Nom,Prenom,Date,TpsTravailJ,IdTra FROM tempsdetravail t INNER JOIN utilisateur U ON t.IdUti = U.IdUti WHERE Superieur = '$Nom $Prenom' ORDER BY Date"); //Sélectionne tous les éléments de la table tempsdetravail les alignants de manière croissante par la date
                    while($tempsdetravail = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $tempsdetravail['Nom'] . " " . $tempsdetravail['Prenom'] .'</td>';
                        echo '<td>'. $tempsdetravail['Date'] . '</td>';
                        echo '<td>'. $tempsdetravail['TpsTravailJ'] . '</td>';
                        echo '<td width=300>';
                        echo '<a class="btn btn-primary" href="travail/update.php?id='.$tempsdetravail['IdTra'].'"><span class="glyphicon glyphicon-pencil"></span> Modifier</a>';
                        echo ' ';
                        echo '<a class="btn btn-danger" href="travail/delete.php?id='.$tempsdetravail['IdTra'].'"><span class="glyphicon glyphicon-remove"></span> Supprimer</a>';
                        echo '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
        <br>
        <br>
        <div class="row">
            <h1><strong>Liste des plages non pointées</strong></h1>
        </div>
        <!-- Tableau affichant toutes les absences -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Nom Prénom</th>
                    <th>Date</th>
                    <th>Plage1</th>
                    <th>Plage2</th>
                    <th>Plage3</th>
                    <th>Statut</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    date_default_timezone_set('Europe/Paris');
                    $date = date('Y-m-d');
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne le nom et prenom de l'utilisateur actuel
                    $sup = $statement->fetch();

                    $Nom = $sup['Nom'];
                    $Prenom = $sup['Prenom'];

                    $statement = $db->query("SELECT Nom,Prenom,Date,Pointage1,Pointage2,Pointage3,DebutPlage1,DebutPlage2,DebutPlage3,FinPlage1,FinPlage2,FinPlage3,IdPlanning,StatutAbs FROM utilisateur u INNER JOIN planning p ON u.IdUti = p.IdUti WHERE Statut = 'Travail' AND Date <= '$date' AND StatutAbs = 'En cours' AND Superieur = '$Nom $Prenom'"); //Sélectionne des éléments de la table planning et utilisateur permettant d'afficher les absences
                    while($absence = $statement->fetch()) 
                    {
                        echo '<tr>';
                        if($absence['Pointage1'] == NULL && $absence['DebutPlage1'] != NULL && $absence['FinPlage1'] != NULL || $absence['Pointage2'] == NULL && $absence['DebutPlage2'] != NULL && $absence['FinPlage2'] != NULL || $absence['Pointage3'] == NULL && $absence['DebutPlage3'] != NULL && $absence['FinPlage3'] != NULL)
                        {
                            echo '<td>'. $absence['Nom'] . " " . $absence['Prenom'] .'</td>';
                            echo '<td>'. $absence['Date'] . '</td>';
                            if($absence['DebutPlage1'] != NULL && $absence['FinPlage1'] != NULL && $absence['Pointage1'] == NULL && $absence['DebutPlage1'] != NULL && $absence['FinPlage1'] != NULL)
                            {
                                echo '<td>'. $absence['DebutPlage1'] . " à " . $absence['FinPlage1'] .'</td>';
                            }
                            else
                            {
                                echo '<td> </td>';
                            }
                            if($absence['DebutPlage2'] != NULL && $absence['FinPlage2'] != NULL && $absence['Pointage2'] == NULL && $absence['DebutPlage2'] != NULL && $absence['FinPlage2'] != NULL)
                            {
                                echo '<td>'. $absence['DebutPlage2'] . " à " . $absence['FinPlage2'] .'</td>';
                            }
                            else
                            {
                                echo '<td> </td>';
                            }
                            if($absence['DebutPlage3'] != NULL && $absence['FinPlage3'] != NULL && $absence['Pointage3'] == NULL && $absence['DebutPlage3'] != NULL && $absence['FinPlage3'] != NULL)
                            {
                                echo '<td>'. $absence['DebutPlage3'] . " à " . $absence['FinPlage3'] .'</td>';
                            }
                            else
                            {
                                echo '<td> </td>';
                            }
                            echo '<td>'. $absence['StatutAbs'] . '</td>';
                            echo '<td width=300>';
                            echo '<a class="btn btn-success" href="travail/accepterabsence.php?id='.$absence['IdPlanning'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="travail/refuserabsence.php?id='.$absence['IdPlanning'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                            echo '</td>';
                        }
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
        <br>
        <br>
        <div class="row">
            <h1><strong>Liste des oublis</strong></h1>
        </div>
        <!-- Tableau affichant tous les oublis -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Nom Prénom</th>
                    <th>Commentaire</th>
                    <th>Date</th>
                    <th>Heure d'arrivée</th>
                    <th>Heure de départ</th>
                    <th>Durée</th>
                    <th>Statut</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne le nom et prenom de l'utilisateur actuel
                    $sup = $statement->fetch();

                    $Nom = $sup['Nom'];
                    $Prenom = $sup['Prenom'];
                    
                    $statement = $db->query("SELECT Nom,Prenom,Commentaire,Date,HeureArrivee,HeureDepart,Duree,LibStatut,IdOubli FROM oubli O INNER JOIN utilisateur U ON O.IdUti = U.IdUti WHERE LibStatut = 'En cours' AND Superieur = '$Nom $Prenom' ORDER BY Date"); //Sélectionne tous les éléments de la table oubli les alignants de manière croissante par la date
                    while($oubli = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $oubli['Nom'] . " " . $oubli['Prenom'] .'</td>';
                        echo '<td>'. $oubli['Commentaire'] . '</td>';
                        echo '<td>'. $oubli['Date'] . '</td>';
                        echo '<td>'. $oubli['HeureArrivee'] . '</td>';
                        echo '<td>'. $oubli['HeureDepart'] . '</td>';
                        echo '<td>'. $oubli['Duree'] . '</td>';
                        echo '<td>'. $oubli['LibStatut'] . '</td>';
                        echo '<td width=300>';
                        echo '<a class="btn btn-success" href="travail/accepteroubli.php?id='.$oubli['IdOubli'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                        echo ' ';
                        echo '<a class="btn btn-danger" href="travail/refuseroubli.php?id='.$oubli['IdOubli'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                        echo '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
        <br>
        <br>
        <div class="row">
            <h1><strong>Liste des congés demandés</strong></h1>
        </div>
        <!-- Tableau affichant tous les congés demandés des employés -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Nom Prénom</th>
                    <th>Date de début</th>
                    <th>Date de fin</th>
                    <th>Période</th>
                    <th>Motif</th>
                    <th>Statut</th> 
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti'"); //Sélectionne le nom et prenom de l'utilisateur actuel
                    $sup = $statement->fetch();

                    $Nom = $sup['Nom'];
                    $Prenom = $sup['Prenom'];
                
                    $statement = $db->query("SELECT Nom,Prenom,DateDeb,DateFin,C.IdPeriode,Motif,LibStatut,IdConges,P.LibPeriode FROM conges C INNER JOIN utilisateur U ON C.IdUti = U.IdUti INNER JOIN periode P ON P.IdPeriode = C.IdPeriode WHERE Superieur = '$Nom $Prenom' AND C.LibStatut = 'En cours' ORDER BY DateDeb"); //Sélectionne tous les éléments de la table congés les alignants de manière croissante par la date
                    while($conges = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $conges['Nom'] . " " . $conges['Prenom'] .'</td>';
                        echo '<td>'. $conges['DateDeb'] . '</td>';
                        echo '<td>'. $conges['DateFin'] . '</td>';
                        echo '<td>'. $conges['LibPeriode'] . '</td>';
                        echo '<td>'. $conges['Motif'] . '</td>';
                        echo '<td>'. $conges['LibStatut'] . '</td>';
                        echo '<td width=300>';
                        echo '<a class="btn btn-success" href="travail/accepter.php?id='.$conges['IdConges'].'"><span class="glyphicon glyphicon-ok"></span> Accepter</a>';
                        echo ' ';
                        echo '<a class="btn btn-danger" href="travail/refuser.php?id='.$conges['IdConges'].'"><span class="glyphicon glyphicon-remove"></span> Refuser</a>';
                        echo '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
    </body>
</html>