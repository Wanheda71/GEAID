<?php 
    session_start();
    include 'database.php';
    global $db;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="../css/styles.css" rel="stylesheet" type="text/css">
    <title>GEAID71</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';  
                            echo'<li><a class="link" href="sortie.php">Départ</a></li>';
                            echo'<li><a class="link" href="demandes.php">Mes Demandes</a></li>'; 
                            echo'<li><a class="link" href="pointages.php">Mes Pointages</a></li>';
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>'; 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 2) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 2 alors ajoute la partie Temps de travail dans la navbar
                            {  
                                echo'<li><a class="link" href="tpstravail.php">Employés</a></li>';
                            } 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            }  
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="header">
        <main>
            <br/>
            <section class="connect-containerconges">
                <div>
                <h1 class="hconges">Veuillez annoncer la date de votre congé souhaité ainsi que votre motif</h1>
                <br>
                <form class="form" action="conges.php" role="form" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="datedeb">Date de début:</label>
                        <input type="date" class="form-control" id="datedeb" name="datedeb" placeholder="Date début">
                    </div>
                    <div class="form-group">
                        <label for="datefin">Date de fin:</label>
                        <input type="date" class="form-control" id="datefin" name="datefin" placeholder="Date fin">
                    </div>
                    <div class="form-group">
                        <label for="periode">Période:</label>
                        <select class="form-control" id="periode" name="periode">
                        <?php
                           $statement = $db->query('SELECT * FROM periode ORDER BY IdPeriode'); //Sélectionne tes les périodes
                            while($Select = $statement->fetch()) 
                            {
                                echo '<option value="'.$Select['IdPeriode'].'">'.$Select['LibPeriode'].'</option>'; //Création d'un combobox qui récupère l'IdPeriode et affichant le LibPeriode
                            }
                        ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="motif">Motif:</label>
                        <textarea type="text" class="form-control" id="motif" name="motif" placeholder="Motif"></textarea>
                    </div>
                    <br>
                    <div class="form-actions">
                        <input type="submit" class="btn btn-success" name="validconges" id="validconges">
                        <a class="btn btn-primary" href="accueil.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                    </div>
                </form>
                
                <?php
                    $iduti = $_SESSION['IdUti'];
                    if(isset($_POST['datedeb']) AND ($_POST['datefin']) AND ($_POST['periode']) AND ($_POST['motif'])) //Si le bouton Envoyer a été déclenché
                    {
                        extract($_POST);
                        $datedeb = $_POST['datedeb'];
                        $datefin = $_POST['datefin'];
                        $periode = $_POST['periode'];
                        $motif = $_POST['motif'];

                        function mssql_escape_string($motif) {
                            return str_replace('\'', '\'\'', $motif);
                        }

                        $motif2 = mssql_escape_string($motif);

                        $statement = $db->query('SELECT LibStatut FROM statut WHERE IdStatut = 1'); //Sélectionne le LibStatut 1
                        $LibEnCours = $statement->fetch();
                        $statut = $LibEnCours['LibStatut'];

                        $statement = $db->prepare("INSERT INTO conges(IdUti,DateDeb,DateFin,IdPeriode,Motif,LibStatut) values('$iduti','$datedeb','$datefin','$periode','$motif2','$statut')"); //Insert les données dans la table conges
                        $statement->execute([
                            'IdUti' => $iduti,
                            'DateDeb' => $datedeb,
                            'DateFin' => $datefin,
                            'IdPeriode' => $periode,
                            'Motif' => $motif2,
                            'LibStatut' => $statut
                            ]);
                        header("Location: accueil.php"); //Redirige vers la page accueil.php lorsque les données sont insérées
                    }
                    else
                    {
                        if(isset($_POST['validconges']) AND (empty($_POST['datedeb'])) || (empty($_POST['motif'])) || (empty($_POST['datefin']))) //Si le bouton à été pressé alors qu'un champ est vide
                        {
                            echo '<br>';
                            echo '<p class="erroroubli">Veuillez insérer toutes les données.</p>';
                        }
                    }
                ?>
                </div>
            </section>
        </main>
    </div>
</body>
</html>