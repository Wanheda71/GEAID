<?php
    require '../database.php'; //Récupère la base de données
    global $db;

    if(!empty($_GET['id'])) //Récupère l'id par l'url
    {
        $id = checkInput($_GET['id']);
    }

    $dateError = $tpstravailError = $date = $tpstravail = "";

    if(!empty($_POST)) 
    {
        //Création des variables
        $date               = checkInput($_POST['date']);
        $tpstravail         = checkInput($_POST['tpstravail']);
        $isSuccess          = true;
       
        if(empty($date)) //Si la variable date est vide alors:
        {
            $dateError = 'Ce champ ne peut pas être vide'; //Message d'erreur
            $isSuccess = false;
        } 
        if(empty($tpstravail)) //Si la variable tpstravail est vide alors:
        {
            $tpstravailError = 'Ce champ ne peut pas être vide'; //Message d'erreur
            $isSuccess = false;
        }
        if (($isSuccess) || ($isSuccess)) 
        { 
            if($isSuccess)
            {
                date_default_timezone_set('Europe/Paris');
                $semaine = date('W',strtotime($date));

                $statement = $db->prepare("UPDATE tempsdetravail set Date = ?, Semaine = ?, TpsTravailJ = ? WHERE IdTra = ?"); //Modifie les valeurs d'un temps de travail pour un utilisateur
                $statement->execute(array($date,$semaine,$tpstravail,$id));
            }
            header("Location: ../tpstravail.php");
        }
           
    }
    else 
    {
        $statement = $db->prepare("SELECT * FROM tempsdetravail where IdTra = ?"); //Prépare la requete qui selectionne toutes les données de tempsdetravail dont l'IdTra correspond à l'id
        $statement->execute(array($id)); //Execution de la requête
        $item = $statement->fetch();
        $date        = $item['Date'];
        $tpstravail  = $item['TpsTravailJ'];
    }

    function checkInput($data) 
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>



<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../../css/styles.css" />
        <link rel="shortcut icon" href="../../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <title>GEAID71 - Page de modification</title>
    </head>
    
    <body>
        <header> 
            <!-- Logo -->
            <div class="wrapper">
                <div class="logo-container">
                    <a href="../accueil.php"><img src="../../images/aide5.png" alt="logo"/></a>
                </div>
            </div>
        </header>

         <div class="container admin">
            <div class="row">
                <h1><strong>Modifier un temps de travail</strong></h1>
                <br>
                <form class="form" action="<?php echo 'update.php?id='.$id;?>" role="form" method="post" enctype="multipart/form-data"> <!-- Création d'un formulaire faisant appel à la page update.php?id -->
                <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" placeholder="Date" value="<?php echo $date;?>">
                        <span class="help-inline"><?php echo $dateError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="tpstravail">Temps de travail:</label>
                        <input type="time" class="form-control" id="tpstravail" name="tpstravail" placeholder="Temps de travail" value="<?php echo $tpstravail;?>">
                        <span class="help-inline"><?php echo $tpstravailError;?></span>
                    </div>
                    <br>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Modifier</button>
                        <a class="btn btn-primary" href="../tpstravail.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                    </div>
                </form>
            </div>
        </div>   
    </body>
</html>