<?php
    //Connexion à la BBD
    require '../database.php';
    global $db;
    session_start();
 
    $idutiError = $dateError = $tpstravailError = $iduti = $date = $tpstravail = "";
    //Si le formulaire n'est pas vide alors:
    if(!empty($_POST)) 
    {
        //Création des variables
        $iduti              = checkInput($_POST['iduti']);
        $date               = checkInput($_POST['date']);
        $tpstravail         = checkInput($_POST['tpstravail']);
        $isSuccess          = true;
        $isUploadSuccess    = false;
        
        if(empty($iduti)) //Si la variable iduti est vide alors:
        {
            $idutiError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        if(empty($date)) //Si la variable date est vide alors:
        {
            $dateError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        } 
        if(empty($tpstravail)) //Si la variable tpstravail est vide alors:
        {
            $tpstravailError = 'Ce champ ne peut pas être vide';//Message d'erreur
            $isSuccess = false;
        }
        else //Sinon
        {
            $isUploadSuccess = true;
        }
        
        if($isSuccess && $isUploadSuccess) //Si $isSuccess && $isUploadSuccess sont true alors on insert les données dans la table tempsdetravail 
        {
            date_default_timezone_set('Europe/Paris');
            $semaine = date('W',strtotime($date));
            
            $statement = $db->prepare("INSERT INTO tempsdetravail (IdUti,Semaine,Date,TpsTravailJ) values(?, ?, ?, ?)");
            $statement->execute(array($iduti,$semaine,$date,$tpstravail));

            header("Location: ../tpstravail.php"); //Redirige vers la page tpstravail.php lorsque les données sont insérées
        }
    }

    function checkInput($data) //Fonction permettant de sécuriser les données entrées dans le formulaire
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../../css/styles.css" />
        <link rel="shortcut icon" href="../../images/logo.aide.a.domicile.71.mains.transparent.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <title>GEAID71 - Page d'insertion</title>
    </head>
    
    <body>
        <header> 
            <!-- Logo -->
            <div class="wrapper">
                <div class="logo-container">
                    <a href="../accueil.php"><img src="../../images/aide5.png" alt="logo"/></a>
                </div>
            </div>
            
        </header>
         <div class="container admin">
            <div class="row">
                <h1><strong>Ajouter un temps de travail</strong></h1>
                <br>
                <!-- Formulaire pour insérer un temps de travail -->
                <form class="form" action="insert.php" role="form" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="iduti">Utilisateur:</label>
                        <select class="form-control" id="iduti" name="iduti">
                        <?php
                            $iduti2 = $_SESSION['IdUti'];

                            $statement = $db->query("SELECT Nom,Prenom FROM utilisateur WHERE IdUti = '$iduti2'"); //Sélectionne le nom et prénom de l'utilisateur correspondant à l'id
                            $sup = $statement->fetch();

                            $Nom = $sup['Nom'];
                            $Prenom = $sup['Prenom'];

                            $statement = $db->query("SELECT IdUti,Nom,Prenom FROM utilisateur WHERE Superieur = '$Nom $Prenom' ORDER BY IdUti"); //Sélectionne tous les N-1 dont l'utilisateur actuel est le supérieur
                            while($Select = $statement->fetch()) 
                            {
                                echo '<option value="'.$Select['IdUti'].'">'.$Select['Nom'].' '.$Select['Prenom'].'</option>';//Création d'un combobox qui récupère l'IdUti et affichant le nom et prenom
                            }
                        ?>
                        </select>
                        <span class="help-inline"><?php echo $idutiError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" placeholder="Date" value="<?php echo $date;?>">
                        <span class="help-inline"><?php echo $dateError;?></span>
                    </div>
                    <div class="form-group">
                        <label for="tpstravail">Temps de travail:</label>
                        <input type="time" class="form-control" id="tpstravail" name="tpstravail" placeholder="Temps de travail" value="<?php echo $tpstravail;?>">
                        <span class="help-inline"><?php echo $tpstravailError;?></span>
                    </div>
                    <br>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Ajouter</button>
                        <a class="btn btn-primary" href="../tpstravail.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                   </div>
                </form>
            </div>
        </div>   
    </body>
</html>