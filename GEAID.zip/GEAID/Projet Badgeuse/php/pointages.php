<?php
    // Connexion à la base de données
    session_start();
    require 'database.php';
    global $db;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/styles.css" />
    <title>GEAID71</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';
                            echo'<li><a class="link" href="sortie.php">Départ</a></li>';  
                            echo'<li><a class="link" href="conges.php">Congés</a></li>';  
                            echo'<li><a class="link" href="demandes.php">Mes Demandes</a></li>';
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>';
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 2) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 2 alors ajoute la partie Temps de travail dans la navbar
                            {  
                                echo'<li><a class="link" href="tpstravail.php">Employés</a></li>';
                            } 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            } 
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="header">
        <main>
            <br/>
            <section class="connect-containertravail">
                <h1 class="hconges">Calculer son temps de travail total entre deux dates</h1>
                <br>
                <form class="form" action="pointages.php" role="form" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="datedeb">Date de début:</label>
                        <input type="date" class="form-control" id="datedeb" name="datedeb" placeholder="Date début">
                    </div>
                    <div class="form-group">
                        <label for="datefin">Date de fin:</label>
                        <input type="date" class="form-control" id="datefin" name="datefin" placeholder="Date fin">
                    </div>
                    <br>
                    <div class="form-actions">
                        <input type="submit" class="btn btn-success" name="validcumul" id="validcumul">
                        <a class="btn btn-primary" href="accueil.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>
                    </div>
                </form>
            </section>
                
            <div class="container admin" align="center">
                <div class="row">
                    <h1><strong>Mon temps de travail total</strong></h1>
                </div>
                <!-- Tableau affichant le temps de travail total -->
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th>Date de début</th>
                            <th>Date de fin</th>
                            <th>Temps de travail total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $iduti = $_SESSION['IdUti'];
                            if(isset($_POST['datedeb']) AND ($_POST['datefin'])) //Si le bouton Envoyer a été déclenché
                            {
                                extract($_POST);
                                $datedeb = $_POST['datedeb'];
                                $datefin = $_POST['datefin'];

                                $statement = $db->query("SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(TpsTravailJ))) as CumulTps FROM tempsdetravail WHERE IdUti = '$iduti' AND Date BETWEEN '$datedeb' AND '$datefin'"); //Fais le cumul du temps de travail entre deux dates
                                $CumulTravail = $statement->fetch();

                                echo '<tr>';
                                echo '<td>'. $datedeb . '</td>';
                                echo '<td>'. $datefin . '</td>';
                                echo '<td>'. $CumulTravail['CumulTps'] . '</td>';
                                echo '</tr>';
                            }
                            else
                            {
                                if(isset($_POST['validcumul']) AND (empty($_POST['datedeb'])) || (empty($_POST['datefin']))) //Si le bouton à été pressé alors qu'un champ est vide
                                {
                                    echo '<br>';
                                    echo '<p class="erroroubli">Veuillez insérer toutes les données.</p>';
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <br/>
            <br>            
            <div class="container admin" align="center">
                <div class="row">
                    <h1><strong>Mon temps de travail par jour</strong></h1>
                </div>
                <!-- Tableau affichant le temps de travail par jour -->
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th>Jour</th>
                            <th>Temps de travail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $iduti = $_SESSION['IdUti'];
                            if(isset($_POST['datedeb']) AND ($_POST['datefin'])) //Si le bouton Envoyer a été déclenché
                            {
                                extract($_POST);
                                $datedeb2 = $_POST['datedeb'];
                                $datefin2 = $_POST['datefin'];

                                $statement = $db->query("SELECT TpsTravailJ, Date FROM tempsdetravail WHERE IdUti = '$iduti' AND Date BETWEEN '$datedeb' AND '$datefin'"); //Fais le cumul du temps de travail par jour
                                while($TravailJ = $statement->fetch())
                                {
                                    echo '<tr>';
                                    echo '<td>'. $TravailJ['Date'] . '</td>';
                                    echo '<td>'. $TravailJ['TpsTravailJ'] . '</td>';
                                    echo '</tr>';
                                }
                            }
                            else
                            {
                                if(isset($_POST['validcumul']) AND (empty($_POST['datedeb'])) || (empty($_POST['datefin']))) //Si le bouton à été pressé alors qu'un champ est vide
                                {
                                    echo '<br>';
                                    echo '<p class="erroroubli">Veuillez insérer toutes les données.</p>';
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <br/>
            <br>
            <div class="container admin" align="center">
                <div class="row">
                    <h1><strong>Mon temps de travail total par semaine</strong></h1>
                </div>
                <!-- Tableau affichant le temps de travail par semaine -->
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th>Date de début</th>
                            <th>Date de fin</th>
                            <th>Semaine</th>
                            <th>Temps de travail total par semaine</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $iduti = $_SESSION['IdUti'];
                            if(isset($_POST['datedeb']) AND ($_POST['datefin'])) //Si le bouton Envoyer a été déclenché
                            {
                                extract($_POST);
                                setlocale(LC_TIME, "fr_FR");
                                echo '<meta charset="utf-8">';
                                date_default_timezone_set('Europe/Paris');
                                $datedeb = date('W',strtotime($_POST['datedeb']));
                                $datefin = date('W',strtotime($_POST['datefin']));
                                $annee = date('Y');
                                if($datedeb == 53 && $_POST['datedeb'] == date('Y-01-01')){$datedeb = 1;}
                                if($datedeb == 53 && $_POST['datedeb'] == date('Y-01-02')){$datedeb = 1;}
                                if($datedeb == 53 && $_POST['datedeb'] == date('Y-01-03')){$datedeb = 1;}
                                if($datedeb == 53 && $_POST['datedeb'] == date('Y-01-04')){$datedeb = 1;}
                                if($datedeb == 53 && $_POST['datedeb'] == date('Y-01-05')){$datedeb = 1;}
                                if($datedeb == 53 && $_POST['datedeb'] == date('Y-01-06')){$datedeb = 1;}
                                if($datedeb <= $datefin)
                                {
                                    $statement = $db->query("SELECT Semaine, SEC_TO_TIME(SUM(TIME_TO_SEC(TpsTravailJ))) as CumulTps FROM tempsdetravail WHERE IdUti = '$iduti' AND Semaine BETWEEN '$datedeb' AND '$datefin' GROUP BY Semaine"); //Fais le cumul du temps de travail de chaque semaine
                                    while($TravailW = $statement->fetch())
                                    {
                                        $timeStart = strtotime("First Monday January {$annee} + ".($TravailW['Semaine'] - 1)." Week");
                                        $timeEnd   = strtotime("First Monday January {$annee} + {$TravailW['Semaine']} Week -1 day");
                                        
                                        echo '<tr>';
                                        echo '<td>'. utf8_encode(strftime("%d %B %Y", $timeStart)) . '</td>';
                                        echo '<td>'. utf8_encode(strftime("%d %B %Y", $timeEnd))  . '</td>';
                                        echo '<td>'. $TravailW['Semaine'] . '</td>';
                                        echo '<td>'. $TravailW['CumulTps'] . '</td>';
                                        echo '</tr>';
                                    }
                                }
                                else
                                {
                                    $statement = $db->query("SELECT Semaine, SEC_TO_TIME(SUM(TIME_TO_SEC(TpsTravailJ))) as CumulTps FROM tempsdetravail WHERE IdUti = '$iduti' AND Semaine BETWEEN '$datefin' AND '$datedeb' GROUP BY Semaine"); //Fais le cumul du temps de travail de chaque semaine
                                    while($TravailW = $statement->fetch())
                                    {
                                        $timeStart = strtotime("First Monday January {$annee} + ".($TravailW['Semaine'] - 1)." Week");
                                        $timeEnd   = strtotime("First Monday January {$annee} + {$TravailW['Semaine']} Week -1 day");
                                        
                                        echo '<tr>';
                                        echo '<td>'. utf8_encode(strftime("%d %B %Y", $timeStart)) . '</td>';
                                        echo '<td>'. utf8_encode(strftime("%d %B %Y", $timeEnd))  . '</td>';
                                        echo '<td>'. $TravailW['Semaine'] . '</td>';
                                        echo '<td>'. $TravailW['CumulTps'] . '</td>';
                                        echo '</tr>';
                                    }
                                }
                            }
                            else
                            {
                                if(isset($_POST['validcumul']) AND (empty($_POST['datedeb'])) || (empty($_POST['datefin']))) //Si le bouton à été pressé alors qu'un champ est vide
                                {
                                    echo '<br>';
                                    echo '<p class="erroroubli">Veuillez insérer toutes les données.</p>';
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <br/>
            <br>
            <div class="container admin" align="center">
                <div class="row">
                    <h1><strong>Mon temps de travail total par mois</strong></h1>
                </div>
                <!-- Tableau affichant le temps de travail par mois -->
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th>Mois</th>
                            <th>Temps de travail total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $iduti = $_SESSION['IdUti'];
                            if(isset($_POST['datedeb']) AND ($_POST['datefin'])) //Si le bouton Envoyer a été déclenché
                            {
                                extract($_POST);
                                $datedeb = date_parse($_POST['datedeb']);
                                $datefin = date_parse($_POST['datefin']);
                                $mois1 = $datedeb['month'];
                                $mois2 = $datefin['month'];

                                $statement = $db->query("SELECT MONTH(date(Date)) AS Mois, SEC_TO_TIME(SUM(TIME_TO_SEC(TpsTravailJ))) as CumulTps FROM tempsdetravail WHERE IdUti = '$iduti' AND MONTH(date(Date)) BETWEEN '$mois1' AND '$mois2' GROUP BY Mois"); //Fais le cumul du temps de travail par mois
                                while($TravailM = $statement->fetch())
                                {
                                    echo '<tr>';
                                    if($TravailM['Mois'] == 1) {$NomMois = 'Janvier';}
                                    if($TravailM['Mois'] == 2) {$NomMois = 'Février';}
                                    if($TravailM['Mois'] == 3) {$NomMois = 'Mars';}
                                    if($TravailM['Mois'] == 4) {$NomMois = 'Avril';}
                                    if($TravailM['Mois'] == 5) {$NomMois = 'Mai';}
                                    if($TravailM['Mois'] == 6) {$NomMois = 'Juin';}
                                    if($TravailM['Mois'] == 7) {$NomMois = 'Juillet';}
                                    if($TravailM['Mois'] == 8) {$NomMois = 'Août';}
                                    if($TravailM['Mois'] == 9) {$NomMois = 'Septembre';}
                                    if($TravailM['Mois'] == 10) {$NomMois = 'Octobre';}
                                    if($TravailM['Mois'] == 11) {$NomMois = 'Novembre';}
                                    if($TravailM['Mois'] == 12) {$NomMois = 'Décembre';}
                                    echo '<td>'. $NomMois . '</td>';
                                    echo '<td>'. $TravailM['CumulTps'] . '</td>';
                                    echo '</tr>';
                                }
                            }
                            else
                            {
                                if(isset($_POST['validcumul']) AND (empty($_POST['datedeb'])) || (empty($_POST['datefin']))) //Si le bouton à été pressé alors qu'un champ est vide
                                {
                                    echo '<br>';
                                    echo '<p class="erroroubli">Veuillez insérer toutes les données.</p>';
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <br>
    <div class="container admin" align="center">
        <div class="row">
            <h1><strong>Mes pointages </strong></h1>
        </div>
        <!-- Tableau affichant tous les pointages -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Date de début</th>
                    <th>Date de fin</th>
                    <th>Temps de travail</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    date_default_timezone_set('Europe/Paris');
                    $mois = date('m');
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT DateDeb,DateFin,TpsTravail FROM pointage WHERE IdUti = '$iduti' AND MONTH(date(DateDeb)) = '$mois' AND DateDeb is not NULL AND DateFin is not NULL ORDER BY DateDeb"); //Sélectionne tous les éléments de la table pointage les alignants de manière croissante par la date dont l'utilisateur conrrespond à l'iduti du même mois.
                    while($pointage = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $pointage['DateDeb'] . '</td>';
                        echo '<td>'. $pointage['DateFin'] . '</td>';
                        echo '<td>'. $pointage['TpsTravail'] . '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
        <br>
        <div class="row">
            <h1><strong>Mes oublis à signaler </strong></h1>
        </div>
        <!-- Tableau affichant tous les oublis à signaler -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Date de début</th>
                    <th>Date de fin</th>
                    <th>Temps de travail</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    date_default_timezone_set('Europe/Paris');
                    $mois = date('m');
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT DateDeb,DateFin,TpsTravail FROM pointage WHERE IdUti = '$iduti' AND DateDeb is NULL OR IdUti = '$iduti' AND DateFin is NULL ORDER BY DateDeb"); //Sélectionne des éléments de la table pointage les alignants de manière croissante par la date dont l'utilisateur conrrespond à l'iduti.
                    while($pointage = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $pointage['DateDeb'] . '</td>';
                        echo '<td>'. $pointage['DateFin'] . '</td>';
                        echo '<td>'. $pointage['TpsTravail'] . '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
        <br>
        <div class="row">
            <h1><strong>Mes oublis en cours de validation</strong></h1>
        </div>
        <!-- Tableau affichant toutes les demandes -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure d'arrivée</th>
                    <th>Heure de départ</th>
                    <th>Durée</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    date_default_timezone_set('Europe/Paris');
                    $mois = date('m');
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT Date,HeureArrivee,HeureDepart,Duree,LibStatut FROM oubli WHERE IdUti = '$iduti' ORDER BY Date"); //Sélectionne tous les éléments de la table oubli les alignants de manière croissante par la date dont l'utilisateur conrrespond à l'iduti.
                    while($oubli = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $oubli['Date'] . '</td>';
                        echo '<td>'. $oubli['HeureArrivee'] . '</td>';
                        echo '<td>'. $oubli['HeureDepart'] . '</td>';
                        echo '<td>'. $oubli['Duree'] . '</td>';
                        echo '<td>'. $oubli['LibStatut'] . '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
    </body>
</html>