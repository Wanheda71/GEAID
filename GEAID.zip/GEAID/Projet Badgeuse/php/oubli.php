<?php 
    session_start();
    include 'database.php';
    global $db;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="../css/styles.css" rel="stylesheet" type="text/css">
    <title>GEAID71</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';  
                            echo'<li><a class="link" href="sortie.php">Départ</a></li>';  
                            echo'<li><a class="link" href="conges.php">Congés</a></li>';  
                            echo'<li><a class="link" href="demandes.php">Mes Demandes</a></li>';
                            echo'<li><a class="link" href="pointages.php">Mes Pointages</a></li>';  
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>';
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 2) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 2 alors ajoute la partie Temps de travail dans la navbar
                            {  
                                echo'<li><a class="link" href="tpstravail.php">Employés</a></li>';
                            } 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            }  
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="header">
        <main>
            <br/>
            <section class="connect-containeroubli">
            <div>
                <h1 class="hconges">Veuillez annoncer la date de votre oubli ainsi que vos horaires de travail</h1>
                <br>
                <?php 
                    $iduti = $_SESSION['IdUti'];
                    if(isset($_POST)) 
                    {
                        echo '<form class="form" action="oubli.php" role="form" method="post" enctype="multipart/form-data">';
                            echo '<div class="form-group">';
                                echo '<label for="date">Date:</label>';
                                echo '<input type="date" class="form-control" id="date" name="date" placeholder="Date">';
                            echo '</div>';
                            echo '<div class="form-group">';
                                echo '<label for="harrivee">Heure d\'arrivée:</label>';
                                echo '<input type="time" class="form-control" id="harrivee" name="harrivee" placeholder="Heure d\'arrivé">';
                            echo '</div>';
                            echo '<div class="form-group">';
                                echo '<label for="hdepart">Heure de départ:</label>';
                                echo '<input type="time" class="form-control" id="hdepart" name="hdepart" placeholder="Heure de départ">';
                            echo '</div>';
                            echo '<div class="form-group">';
                                echo '<label for="commentaire">Commentaire:</label>';
                                echo '<textarea type="text" class="form-control" id="commentaire" name="commentaire" placeholder="Votre commentaire"></textarea>';
                            echo '</div>';
                            echo '<br>';
                            echo '<div class="form-actions">';
                                echo '<input type="submit" class="btn btn-success" name="validoubli" id="validoubli">';
                                echo '<a class="btn btn-primary" href="accueil.php"><span class="glyphicon glyphicon-arrow-left"></span> Retour</a>';
                            echo '</div>';
                        echo '</form>';

                        if(isset($_POST['date']) AND ($_POST['harrivee']) AND ($_POST['hdepart'])) //Si le bouton Envoyer a été déclenché
                        {
                            extract($_POST);
                            $date = $_POST['date'];
                            $harrivee = $_POST['harrivee'];
                            $hdepart = $_POST['hdepart'];
                            $commentaire = $_POST['commentaire'];

                            function mssql_escape_string($commentaire) {
                                return str_replace('\'', '\'\'', $commentaire);
                            }

                            $commentaire2 = mssql_escape_string($commentaire);

                            date_default_timezone_set('Europe/Paris');
                            $start = new \DateTime("{$harrivee}");
                            $end = new \DateTime("{$hdepart}");
                            $diff = $start->diff($end); //Calcule la différence entre l'heure de départ et l'heure de sortie
                            $diffStr = $diff->format('%H:%I:%S');

                            if($harrivee < $hdepart)
                            {
                                $statement = $db->prepare("INSERT INTO oubli(IdUti,Commentaire,Date,HeureArrivee,HeureDepart,Duree,LibStatut) values('$iduti','$commentaire2','$date','$harrivee','$hdepart','$diffStr','En cours')"); //Insert les données dans la table oubli
                                $statement->execute([
                                    'IdUti' => $iduti,
                                    'Commentaire' => $commentaire2,
                                    'Date' => $date,
                                    'HeureArrivee' => $harrivee,
                                    'HeureDepart' => $hdepart,
                                    'Duree' => $diffStr,
                                    'LibStatut' => 'En cours'
                                    ]);
                                header("Location: accueil.php"); //Redirige vers la page accueil.php lorsque les données sont insérées
                            }
                            else
                            {
                                echo '<br>';
                                echo '<p class="erroroubli">L\'heure d\'arrivée ne peut être supérieur à celle de départ.</p>';
                            }
                        }
                        else
                        {
                            if(isset($_POST['validoubli']) AND (empty($_POST['date'])) || (empty($_POST['harrivee'])) || (empty($_POST['hdepart']))) //Si le bouton à été pressé alors qu'un champ est vide
                            {
                                echo '<br>';
                                echo '<p class="erroroubli">Veuillez insérer toutes les données.</p>';
                            }
                        }
                    }
                ?>
                </div>
            </section>
        </main>
    </div>
</body>
</html>