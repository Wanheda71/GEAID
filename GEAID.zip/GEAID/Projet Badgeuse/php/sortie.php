<?php 
    session_start();
    include 'database.php';
    global $db;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../css/styles.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <title>GEAID71</title>
</head>
<body>
    <header>
        <div class="wrapper">
        <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';  
                            echo'<li><a class="link" href="conges.php">Congés</a></li>';  
                            echo'<li><a class="link" href="demandes.php">Mes Demandes</a></li>';  
                            echo'<li><a class="link" href="pointages.php">Mes Pointages</a></li>';
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>';
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 2) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 2 alors ajoute la partie Temps de travail dans la navbar
                            {  
                                echo'<li><a class="link" href="tpstravail.php">Employés</a></li>';
                            } 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            }  
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="header">
        <main>
            <br/>
            <section class="connect-container">
                <div>
                    <?php
                        $iduti = $_SESSION['IdUti'];

                        $maxid = $db->query("SELECT MAX(Id) as MaxId FROM pointage WHERE IdUti = '$iduti'"); //Selectionne la dernière ligne de la table pointage l'utilisateur correspond à l'id
                        $MaxId = $maxid->fetch();

                        $datedeb = $db->query("SELECT DateDeb, DATE_FORMAT(DateDeb, '%Y/%m/%d') AS Date, DATE_FORMAT(DateDeb, '%H:%i:%s') AS Heure FROM pointage WHERE IdUti = '$iduti' AND Id = '".$MaxId['MaxId']."' AND DateFin is NULL"); //Sélectionne DateDeb, la date et l'heure de DateDeb de la dernière ligne de l'utilisateur dont la DateFin est nulle.
                        $DateDeb = $datedeb->fetch();
                        
                        if($DateDeb['DateDeb'] != NULL)
                        {
                            echo '<h1 class="infoarrivee">Votre arrivée a eu lieu le '.$DateDeb['Date'].' à '.$DateDeb['Heure'].'</h1><br>';
                        }
                        else
                        {
                            echo '<h1 class="infoarrivee2">Attention, vous n\'avez pas validé votre arrivée</h1><br>';
                        }
                    ?>
                    <form method="POST">
                        <input class="btnba" type="submit" value="Départ" name="badgesortie" id="badgesortie">
                    </form>
                    <form action="oubli.php" method="POST"> 
                        <a href="oubli.php"><input class="btnoubli" type="submit" value="Cliquez ici si vous avez oublié de valider votre départ" name="oublisortie" id="oublisortie"></a>
                    </form>
                </div>
                <?php 
                    date_default_timezone_set('Europe/Paris');
                    $heure = date('H:i:s');
                    $dateheure = date('Y-m-d H:i:s');
                    $date = date('Y-m-d');
                    $semaine = date('W',strtotime($date));
                    $iduti = $_SESSION['IdUti'];
                    
                    if(isset($_POST['badgesortie'])) 
                    {
                        extract($_POST);

                        $maxid = $db->query("SELECT MAX(Id) as MaxId FROM pointage WHERE IdUti = '$iduti'"); //Selectionne la dernière ligne de la table pointage l'utilisateur correspond à l'id
                        $MaxId = $maxid->fetch();

                        $Sortie = $db->prepare("UPDATE pointage SET DateFin = '$dateheure' WHERE IdUti = '$iduti' AND Id = '".$MaxId['MaxId']."'"); //Modifie la dernière ligne de la table pointage modifiant la date de fin lors de l'appui sur le bouton sortie
                        $Sortie->execute([
                            'DateFin' => $dateheure
                        ]);

                        
                        $diff = $db->query("SELECT DateDeb, DateFin FROM pointage WHERE IdUti = '$iduti' AND Id = '".$MaxId['MaxId']."'"); //Sélectionne la date de début et la date de fin de la dernière ligne de la table pointage dont l'utilisateur correspond à l'id
                        $Diff = $diff->fetch();
                        
                        $start = new \DateTime("{$Diff['DateDeb']}");
                        $end = new \DateTime("{$Diff['DateFin']}");
                        $diff = $start->diff($end); //Calcule la différence entre la date de début et la date de fin
                        $diffStr = $diff->format('%H:%I:%S');

                        if($diffStr <= '08:00:00')
                        {
                            $TpsTravail = $db->prepare("UPDATE pointage SET TpsTravail = '$diffStr' WHERE IdUti = '$iduti' AND Id = '".$MaxId['MaxId']."'"); //Modifie la dernière ligne de la table pointage modifiant le temps de travail correspondant à la différence entre la date de début et la date de fin dont l'utilisateur correspond à l'id
                            $TpsTravail->execute([
                                'TpsTravail' => $diffStr
                            ]);
                            header('Location: svalidation.php');
                        }
                        else
                        {
                            $TpsTravail = $db->prepare("UPDATE pointage SET TpsTravail = '00:00:00', DateDeb = NULL WHERE IdUti = '$iduti' AND Id = '".$MaxId['MaxId']."'"); //Modifie la dernière ligne de la table pointage modifiant le temps de travail correspondant à la différence entre la date de début et la date de fin dont l'utilisateur correspond à l'id
                            $TpsTravail->execute([
                                'TpsTravail' => $diffStr
                            ]);
                            header('Location: salerte.php');
                        }
                        
                        $tpstravail = $db->query("SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(TpsTravail))) AS TpsTravailJour FROM pointage WHERE IdUti = '$iduti' AND DATE(DateDeb) = '$date'"); //Somme des TpsTravail de la table pointage correspondant à la date actuelle et dont l'utilisateur correspond à l'id
                        $TpsTravailJ = $tpstravail->fetch();

                        $TravailJourS = 0;
                        $TravailJourS = $TpsTravailJ['TpsTravailJour'];
                        $TravailJour = $TravailJourS;
                        
                        $maxidtra = $db->query("SELECT MAX(IdTra) as MaxTra FROM tempsdetravail WHERE IdUti = '$iduti'"); //Sélectionne la dernière ligne de la table tempsdetravail dont l'utilisateur correspond à l'id
                        $MaxIdTra = $maxidtra->fetch();
                        $datetpstravail = $db->query("SELECT Date FROM tempsdetravail WHERE IdUti = '$iduti' AND IdTra = '".$MaxIdTra['MaxTra']."'"); //Sélectionne la date qui correspond à la dernière ligne de la table temps de travail et dont l'utilisateur correspond à l'id
                        $DateTpsTravail = $datetpstravail->fetch();

                        if($DateTpsTravail['Date'] != $date){ //Si la date de la dernière ligne ne correspond pas à la date actuelle
                            $TravailParJour = $db->prepare("INSERT INTO tempsdetravail(IdUti, Semaine, Date, TpsTravailJ) VALUES('$iduti', '$semaine', '$date', '$TravailJour')"); //Insert une nouvelle ligne dans la table tempsdetravail
                            $TravailParJour->execute([
                            'IdUti' => $iduti,
                            'Semaine' => $semaine,
                            'Date' => $date,
                            'TpsTravailJ' => $TravailJour
                            ]);
                        } else {
                            $UpTpsTravail = $db->prepare("UPDATE tempsdetravail SET TpsTravailJ = '$TravailJour' WHERE IdUti = '$iduti' AND Date = '$date'"); //Sinon modifie le TpsTravailJ de la dernière ligne
                            $UpTpsTravail->execute([
                                'TpsTravailJ' => $TravailJour
                            ]);
                        }

                        $statement = $db->query("SELECT MAX(Id) AS ID FROM pointage WHERE IdUti = '$iduti'"); //Sélectionne la dernière ligne de la table pointage dont l'utilisateur correspond à l'id
                        $ID = $statement->fetch();

                        $statement = $db->query("SELECT NumPointage, date(DateDeb) as DateDeb FROM pointage WHERE Id = '".$ID['ID']."'"); //Sélectionne des données de la dernière ligne de la table pointage dont l'utilisateur correspond à l'id
                        $ID2 = $statement->fetch();

                        if($ID2['NumPointage'] == 1)
                        {
                            $UpPlan = $db->prepare("UPDATE planning SET Pointage1 = 'OK' WHERE IdUti = '$iduti' AND Date = '$date'"); //Modifie le Pointage1 de l'utilisateur en fonction de la date
                            $UpPlan->execute([
                                'Pointage1' => 'OK'
                            ]);
                        }
                        elseif($ID2['NumPointage'] == 2)
                        {
                            $UpPlan = $db->prepare("UPDATE planning SET Pointage2 = 'OK' WHERE IdUti = '$iduti' AND Date = '$date'"); //Modifie le Pointage2 de l'utilisateur en fonction de la date
                            $UpPlan->execute([
                                'Pointage2' => 'OK'
                            ]);
                        }
                        elseif($ID2['NumPointage'] == 3)
                        {
                            $UpPlan = $db->prepare("UPDATE planning SET Pointage3 = 'OK' WHERE IdUti = '$iduti' AND Date = '$date'"); //Modifie le Pointage3 de l'utilisateur en fonction de la date
                            $UpPlan->execute([
                                'Pointage3' => 'OK'
                            ]);
                        }
                    } 
                ?>
            </section>
        </main>
    </div>
</body>
</html>