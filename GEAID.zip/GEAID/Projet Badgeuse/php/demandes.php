<?php
    // Connexion à la base de données
    session_start();
    require 'database.php';
    global $db;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="../images/logo.aide.a.domicile.71.mains.transparent.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/styles.css" />
    <title>GEAID71</title>
</head>
<body>
<header>
        <div class="wrapper">
            <nav>
                <ul class="nav-links">
                    <div class="logo-container">
                        <a href="accueil.php"><img src="../images/aide6.png" alt="logo"/></a>
                    </div>
                    <?php
                        if(isset($_SESSION['Mail']) and $_SESSION['Mdp']) //Si les sessions Mail et Mdp ne sont pas nulles alors affiche la navbar principale
                        {   
                            echo'<li><a class="link" href="accueil.php">Accueil</a></li>';  
                            echo'<li><a class="link" href="entree.php">Arrivée</a></li>';
                            echo'<li><a class="link" href="sortie.php">Départ</a></li>';  
                            echo'<li><a class="link" href="conges.php">Congés</a></li>';  
                            echo'<li><a class="link" href="pointages.php">Mes Pointages</a></li>';
                            echo'<li><a class="link" href="planning.php">Mon Planning</a></li>';
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 2) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 2 alors ajoute la partie Temps de travail dans la navbar
                            {  
                                echo'<li><a class="link" href="tpstravail.php">Employés</a></li>';
                            } 
                            if(isset($_SESSION['Mail']) and $_SESSION['Mdp'] and $_SESSION['NumRole'] == 3) //Si les sessions Mail, Mdp ne sont pas nulles et que le NumRole est égal à 3 alors ajoute la partie Administration dans la navbar
                            {  
                                echo'<li><a class="link" href="../admin/index.php">Administration</a></li>';
                            } 
                            echo'</li>';        
                            echo'<li><a class="link" href="logout.php">Déconnexion</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container admin" align="center">
        <div class="row">
            <h1><strong>Mes demandes de congés </strong></h1>
        </div>
        <!-- Tableau affichant toutes les demandes -->
        <table class="table table-stripped table-bordered">
            <thead>
                <tr>
                    <th>Date de début</th>
                    <th>Date de fin</th>
                    <th>Période</th>
                    <th>Motif</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $iduti = $_SESSION['IdUti'];

                    $statement = $db->query("SELECT DateDeb,DateFin,Motif,LibStatut,LibPeriode FROM conges C INNER JOIN periode P ON C.IdPeriode = P.IdPeriode WHERE IdUti = '$iduti' ORDER BY DateDeb"); //Sélectionne tous les éléments de la table conges les alignants de manière croissante par la date dont l'utilisateur conrrespond à l'iduti
                    while($conges = $statement->fetch()) 
                    {
                        echo '<tr>';
                        echo '<td>'. $conges['DateDeb'] . '</td>';
                        echo '<td>'. $conges['DateFin'] . '</td>';
                        echo '<td>'. $conges['LibPeriode'] . '</td>';
                        echo '<td>'. $conges['Motif'] . '</td>';
                        echo '<td>'. $conges['LibStatut'] . '</td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
    </body>
</html>